package main;

import dijkstra.*;
import maze.*;
import interfaces.*;
import java.awt.event.*;
import java.util.* ;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

/** Main class of the program. It inherits from GameController to create a fully functional graphical maze solver,
 *  using the Dijkstra algorithm.
 *  @author Olivier Roques
 *  @author Erwan Culerier
 */

public class MainMaze extends GameController
{
	/* The main method. By default, it creates a 60x40 maze with 20 pixels wide cell. It also adds a menu bar to
	 * the frame and print instructions at launch.*/
	public static void main(String[] args) 
	{
		MainMaze maze = new MainMaze("Maze", 60, 40, 20, 20) ;
		GameFrame frame = maze.getFrame();
		GameMenuBar menu = new GameMenuBar(frame, maze);
		frame.initializeWithMenu(menu);
		maze.printInformations();
	}
	
	private final GameModel  gameModel ;
	private Maze maze; 				      // The main maze
	private MBox departure;				  // The starting cell
	private MBox arrival;				  // The exit cell
	private ArrayList<VertexInterface> chemin;   // Will contain the shortest path from 'departure' to 'arrival'
	
	/** Constructor of the frame and the maze:
	 * 
	 * @param name The name of the frame
	 * @param gameWidth  The width of the frame (and the maze) in blocks.
	 * @param gameHeight The height of the frame (and the maze) in blocks.
	 * @param blockWidth The width of a block, in pixels.
	 * @param blockHeight The height of a block, in pixels.
	 * @see Maze
	 * @see GameModel
	 */
	public MainMaze(String name, int gameWidth, int gameHeight, int blockWidth, int blockHeight)
	{
		super(name, gameWidth, gameHeight, blockWidth, blockHeight) ;
		
		this.gameModel = new GameModel(gameWidth,gameHeight,blockWidth,blockHeight) ;
		this.maze = new Maze(gameWidth, gameHeight);
	}
	
	/** Invoked when the mouse button has been clicked (pressed and released) on a component. 
	 * It changes an empty cell to a wall (and a wall to an empty block) or a starting block while SHIFT is pressed.
	 * An arrival block can be created with a SHIFT-click on a starting block.*/
	@Override
	public final synchronized void mouseClicked(MouseEvent e)
	{
		synchronized (gameModel) {
			int x = getGameX(e) ;
			int y = getGameY(e) ;
			MBox cell = this.maze.getBox(y, x);
			
			if (e.isShiftDown() && cell.getLabel() == "E"){
				cell.setLabel("D");
				gameModel.set(x, y, (byte)8);
			}
			else if (e.isShiftDown() && cell.getLabel() == "D"){
				cell.setLabel("A");
				gameModel.set(x, y, (byte)10);
			}
			else if (cell.getLabel() == "W"){
				cell.setLabel("E");
				gameModel.set(x, y, (byte)0);
			}
			else if (cell.getLabel() == "E"){
				cell.setLabel("W");
				gameModel.set(x, y, (byte)4);
			}
			else if (cell.getLabel() == "A"){
				cell.setLabel("E");
				gameModel.set(x, y, (byte)0);
			}
			
			notify(gameModel) ;
		}
	}
	
	/** Invoked when a mouse button is pressed on a component and then dragged. 
	 *  MOUSE_DRAGGED events will continue to be delivered to the component 
	 *  where the drag originated until the mouse button is 
	 *  released regardless of whether the mouse position is within the 
	 *  bounds of the component. Here, it is used to create continuous walls or empty blocks.
	 */
	@Override
	public final synchronized void mouseDragged(MouseEvent e)
	{
		synchronized (gameModel) {
			int x = getGameX(e) ;
			int y = getGameY(e) ;
			MBox cell = this.maze.getBox(y, x);
			
			if (SwingUtilities.isLeftMouseButton(e) && cell.getLabel() == "E"){
				cell.setLabel("W");
				gameModel.set(x, y, (byte)4);
			}		
			else if (SwingUtilities.isRightMouseButton(e) && cell.getLabel() == "W") {
				cell.setLabel("E");
				gameModel.set(x, y, (byte)0);
			}
			notify(gameModel) ;
		}
	}
	
	/** This method tests whether or not a starting and exit block exist and redefines 
	 * 'arrival' and 'departure' accordingly.
	 * @return A boolean: true if there are a starting and an exit block, false in other cases.
	 */
	private boolean isThereCaseDandA(){
		boolean isThereCaseD = false;
		boolean isThereCaseA = false;
		for(int i = 0; i<gameHeight; i++){
			for(int j = 0; j<gameWidth; j++){
				if (!isThereCaseA && maze.getBox(i, j).getLabel() == "A"){
					this.arrival = maze.getBox(i, j);
					isThereCaseA = true;
				}
				if (!isThereCaseD && maze.getBox(i, j).getLabel() == "D"){
					this.departure = maze.getBox(i, j);
					isThereCaseD = true;
				}
				if (isThereCaseA && isThereCaseD) return true;
			}
		}
		return false;
	}
	
	/** Invoked when a key has been typed. 
	 *  See the class description for KeyEvent for a definition of a key typed event.
	 *  Here, four keys are detected: r, o, s and e.
	 */
	@Override
	public final synchronized void keyTyped(KeyEvent e)
	{
		char key = e.getKeyChar() ;
		
		switch (key) {
		case 'r':
			resolve();
			break;			
		case 'o' :
			open();
			break;			
		case 's' :
			saveAs();
			break ;			
		case 'e' :
			reinit() ;
			break ;
		}
	}
	
	/** Triggered by the pressing of the 'r' key, or through the menu bar.
	 * Resolves the maze created by the user. Notifies the user if a starting or an exit block is missing
	 * or if there are no solutions to the maze.
	 * @see Dijkstra
	 * @see Previous
	 */
	public void resolve(){
		if (isThereCaseDandA()){
			if (this.chemin != null){   // Clear previous paths if necessary
				synchronized (gameModel){
					MBox cell;
					for(int i = 1; i < chemin.size()-1; i++){
						cell = (MBox)chemin.get(i);
						if (cell.getLabel() == "E"){   // To prevent the suppression of walls created by the user
							gameModel.set(cell.getCoordinateW(), cell.getCoordinateH(), (byte)0);
						}
					}
				notify(gameModel);
				}
			}
			PreviousInterface previous = Dijkstra.dijkstra(this.maze, this.departure);
			this.chemin = previous.getShortestPathTo(this.arrival);
			if (chemin.size() > 1){  // Detect if a solution has indeed been found
				synchronized (gameModel){
					MBox cell;
					for(int i = 1; i < chemin.size()-1; i++){  //Take account of the starting and exit block
						cell = (MBox)chemin.get(i);
						gameModel.set(cell.getCoordinateW(), cell.getCoordinateH(), (byte)6);
					}
					notify(gameModel);
				}
				JOptionPane.showMessageDialog(this.getFrame(), "Le plus court chemin calculé fait " 
						+ (chemin.size()-1) + " cases.", "Résultat", JOptionPane.INFORMATION_MESSAGE);
			}
			else{
				JOptionPane.showMessageDialog(this.getFrame(), "Il n'existe pas de solutions à ce labyrinthe !", "Pas de solutions",
						JOptionPane.INFORMATION_MESSAGE);
			} 
		}
		else{
			JOptionPane.showMessageDialog(this.getFrame(), "Il manque la case de départ ou d'arrivée !", "Erreur",
					JOptionPane.ERROR_MESSAGE);
		}
		return;
	}
	
	/** Triggered by the pressing of the 'o' key, or through the menu bar.
	 * 	Offers the option to initialize a new maze from a text file through
	 * a window implemented in JFileChooser.
	 * @see Maze#initFromTextFile(String)
	 */
	public void open(){
		JFileChooser chooser = new JFileChooser("data");
	    FileNameExtensionFilter filter = new FileNameExtensionFilter(
	        "Texte", "txt");
	    chooser.setFileFilter(filter);
	    int returnVal = chooser.showOpenDialog(null);
	    String path;
	    if(returnVal == JFileChooser.APPROVE_OPTION) {
	       path = chooser.getSelectedFile().getAbsolutePath();
	    }
	    else
	    {
	    	return;
	    }
		try {
			reinit();
			maze.initFromTextFile(path);
			synchronized (gameModel) 
			{
				for(int i = 0; i<gameHeight; i++){
					for(int j = 0; j<gameWidth; j++){
						String type = maze.getBox(i, j).getLabel() ;
						switch (type)
						{
						case "A" :
							gameModel.set(j, i,(byte) 10);
							break ;
						case "E" :
							gameModel.set(j, i, (byte) 0);
							break ;
						case "W" :
							gameModel.set(j, i, (byte) 4);
							break ;
						case "D" :
							gameModel.set(j, i, (byte) 8);
							break ;
						}
					}
				}
				notify(gameModel) ;
			}
		} catch (MazeReadingException e1) {
			e1.printStackTrace();
		}
		return;
	}
	
	/** Triggered by the pressing of the 's' key, or through the menu bar.
	 * 	Offers the option to save the current maze in a text file through
	 * a window implemented in JFileChooser.
	 * @see Maze#saveToTextFile(String)
	 */
	public void saveAs(){
		JFileChooser chooser2 = new JFileChooser("data");
	    FileNameExtensionFilter filter2 = new FileNameExtensionFilter(
	        "Texte", "txt");
	    chooser2.setFileFilter(filter2);
	    int returnVal2 = chooser2.showSaveDialog(null);
	    String path2;
	    if(returnVal2 == JFileChooser.APPROVE_OPTION) {
	       path2 = chooser2.getSelectedFile().getAbsolutePath();
	    }
	    else
	    {
	    	return;
	    }
		maze.saveToTextFile(path2);
		return ;
	}
	
	/** Triggered by the pressing of the 'e' key, or through the menu bar.
	 * 	Clear the window and the maze and refresh the maze accordingly.
	 */
	public void reinit() {
		this.chemin = null;
		synchronized (gameModel){
			MBox cell;
			for(int i = 0; i<gameHeight; i++){
				for(int j = 0; j<gameWidth; j++){
					cell = this.maze.getBox(i, j);
					cell.setLabel("E");
					gameModel.set(j, i, (byte) 0);
				}
			}
		notify(gameModel);
		}
	}
	
	/** Print instructions to use the program on first launch.*/
	public void printInformations(){
		JOptionPane.showMessageDialog(this.getFrame(), "Bonjour !\n "
			+ "Le labyrinthe est au départ constitué de cases vides, il faut alors y dessiner les murs avec le clic gauche (ou les effacer avec le clic droit).\n"
			+ "Maintenez SHIFT enfoncé et cliquez sur une case vide pour ajouter une case de départ, et recliquez à nouveau pour définir une case d'arrivée.\n "
			+ "Appuyez ensuite sur 'r' pour résoudre le labyrinthe, 'e' pour effacer la fenêtre, 's' pour enregistrer votre labyrinthe.\n "
			+ "Vous pourrez alors ouvrir un labyrinthe existant avec 'o'.\n"
			+ "Toutes ces actions peuvent aussi être réalisées à l'aide de la barre de menus.", "Instructions", JOptionPane.INFORMATION_MESSAGE);
	}
	
	/** Invoked when a mouse button has been pressed on a component. */
	@Override
	public final synchronized void mousePressed(MouseEvent e)
	{
		
	}
	
	/** Invoked when a mouse button has been released on a component. */
	@Override
	public final synchronized void mouseReleased(MouseEvent e)
	{
			
	}
	
	/** Invoked when the mouse enters a component. */
	@Override
	public final synchronized void mouseEntered(MouseEvent e)
	{
				
	}
	
	/** Invoked when the mouse exits a component. */
	@Override
	public final synchronized void mouseExited(MouseEvent e)
	{
				
	}
	
	/** Invoked when the mouse cursor has been moved onto a 
	 *  component but no buttons have been pushed.
	 */
	@Override
	public final synchronized void mouseMoved(MouseEvent e)
	{
		
	}

	/** Invoked when a key has been pressed. 
	 *  See the class description for KeyEvent for a definition of a key pressed event.
	 */
	@Override
	public final synchronized void keyPressed(KeyEvent e)
	{
		
	}

	/** Invoked when a key has been released. 
	 *  See the class description for KeyEvent for a definition of a key released event. 
	 */
	@Override
	public final synchronized void keyReleased(KeyEvent e)
	{
		
	}

}
package main;

import maze.*;

/** Test for writing and reading a maze in or from a text file.
 * @see Maze#initFromTextFile(String)
 * @see Maze#saveToTextFile(String)*/

public class MainTest {

	public static void main(String[] args) {
		Maze maze = new Maze(1,1);
		try {
			maze.initFromTextFile("data/labyrinthe.txt") ;
			maze.saveToTextFile("data/labyrinthe2.txt");
		} catch (MazeReadingException e) {
			e.printStackTrace();
		}
	}
}

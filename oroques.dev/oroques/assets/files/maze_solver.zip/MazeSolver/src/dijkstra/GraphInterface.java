package dijkstra;
import java.util.ArrayList;

/** Interface of the graph occurring in the Dijkstra algorithm. */

public interface GraphInterface {
	
	/** Return an array containing the vertices of the graph. 
	 * @return An ArrayList of VertexInterface.
	 * @see VertexInterface
	 * @see ArrayList*/
	public ArrayList<VertexInterface> getAllVertices();
	
	/** Return an array containing the adjacent vertices of a given vertex. 
	 * @param vertex The vertex to find the adjacent vertices to.
	 * @return An ArrayList of VertexInterface.
	 * @see VertexInterface
	 * @see ArrayList */
	public ArrayList<VertexInterface> getSuccessors(VertexInterface vertex);
	
	/** Test if vertex src is adjacent to vertex dst.
	 *  Return the cost of the edge (src, dst) if dst is adjacent to src;
	 *  Return -1 otherwise.
	 *  @param src The first vertex of the edge (src, dst).
	 *  @param dst The second vertex of the edge (src, dst).
	 *  @return An integer representing the weight of the edge, of value -1 if the edge does not exist.
	 */
	public int getWeight(VertexInterface src, VertexInterface dst);
}

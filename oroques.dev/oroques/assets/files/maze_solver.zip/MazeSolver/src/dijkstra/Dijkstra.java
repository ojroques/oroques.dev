package dijkstra;
import java.util.ArrayList;

/** Implementation of the Dijkstra algorithm
 *  using object interfaces only.
 */

public class Dijkstra {
	
	/** The Dijkstra algorithm itself. */
	private static PreviousInterface dijkstra(GraphInterface g, VertexInterface r, ASetInterface a, PiInterface pi, PreviousInterface previous){
		a.add(r);
		VertexInterface pivot = r;
		ArrayList<VertexInterface> allVertices = g.getAllVertices();
		final int N = allVertices.size();
		
		pi.setValue(r, 0);
		for(VertexInterface x: allVertices){
			if (!x.equals(r)) pi.setValue(x, Integer.MAX_VALUE);
		}
		
		for(int i = 0; i < N; i++){
			ArrayList<VertexInterface> allSuccessors = g.getSuccessors(pivot);
			
			for(VertexInterface y: allSuccessors){
				if (!a.contains(y) && pi.getValue(pivot) + g.getWeight(pivot, y) < pi.getValue(y)){
					pi.setValue(y, pi.getValue(pivot) + g.getWeight(pivot, y));
					previous.setValue(y, pivot);
				}
			}
			
			int mini = Integer.MAX_VALUE;
			for(VertexInterface y: allVertices){
				if(!a.contains(y) && pi.getValue(y) < mini){
					mini = pi.getValue(y);
					pivot = y;
				}
			}
			a.add(pivot);
		}
		
		return previous;
	}
	
	/**Application of the Dijkstra algorithm to a given graph and starting vertex.
	 * 
	 * @param g The graph on which the Dijkstra algorithm is applied to.
	 * @param r The starting vertex of the graph.
	 * @return  A Previous object, which grants access to the shortest paths from r to a chosen vertex.
	 * @see Previous
	 * @see Previous#getShortestPathTo
	 */
	public static PreviousInterface dijkstra(GraphInterface g, VertexInterface r){
		return dijkstra(g, r, new ASet(), new Pi(), new Previous());
	}
}

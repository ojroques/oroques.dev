package dijkstra;
import java.util.HashSet;

/** Class of the set A occurring in the Dijkstra algorithm.
 *  The set A is a set of vertices characterized by the
 *  VertexInterface interface.
 */

public class ASet implements ASetInterface {
	
	/** The set is implemented with a HashSet and contains vertices.
	 * @see HashSet */
	private HashSet<VertexInterface> set = new HashSet<VertexInterface>();
		
	@Override
	public void add(VertexInterface vertex) {
		this.set.add(vertex);
	}

	@Override
	public boolean contains(VertexInterface vertex) {
		return this.set.contains(vertex);
	}
}

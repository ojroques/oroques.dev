package dijkstra;
import java.util.Hashtable;

/** Interface of the pi function occurring in the Dijkstra algorithm. */

public class Pi implements PiInterface {
	
	/** The Pi function is implemented with a HashTable, with vertices as keys and integers as values.
	 * @see VertexInterface
	 * @see Hashtable*/
	private Hashtable<VertexInterface, Integer> poidsSommet = new Hashtable<VertexInterface, Integer>();

	@Override
	public void setValue(VertexInterface vertex, int value) {
		this.poidsSommet.put(vertex, value);
	}

	@Override
	public int getValue(VertexInterface vertex) {
		return this.poidsSommet.get(vertex);
	}

}

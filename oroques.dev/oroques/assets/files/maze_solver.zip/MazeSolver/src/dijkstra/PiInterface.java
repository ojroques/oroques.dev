package dijkstra;

/** Interface of the pi function occurring in the Dijkstra algorithm. */

public interface PiInterface {
	/** Setting the result for a vertex. 
	 * @param vertex The vertex of which the value will be associated to.
	 * @param value The chosen value for the vertex.*/
	public void setValue(VertexInterface vertex, int value);
	
	/** Returns the value for a vertex. 
	 * @param vertex The vertex chosen.
	 * @return An integer which is the value of the vertex.*/
	public int getValue(VertexInterface vertex);
}

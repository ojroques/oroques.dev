package dijkstra;

/** Interface of the set A occurring in the Dijkstra algorithm.
 *  The set A is a set of vertices characterized by the
 *  VertexInterface interface.
 */

public interface ASetInterface {
	/** Add a vertex to the set A. 
	 *  @param vertex The vertex to add to the set*/
	public void add(VertexInterface vertex);
	
	/** Testing membership of a vertex. 
	 * 	@param vertex The vertex to test the membership with.
	 *  @return A boolean.*/
	public boolean contains(VertexInterface vertex);
}

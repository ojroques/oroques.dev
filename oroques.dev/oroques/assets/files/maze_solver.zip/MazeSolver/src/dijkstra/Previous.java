package dijkstra;
import java.util.ArrayList;
import java.util.Hashtable;

/** Class of the previous function occurring in the Dijkstra algorithm. */

public class Previous implements PreviousInterface {
	
	/** The previous function is implemented with HashTable, with vertices as both keys and values.
	 * @see VertexInterface
	 * @see Hashtable*/
	private Hashtable<VertexInterface, VertexInterface> correspondance = new Hashtable<VertexInterface, VertexInterface>();
	
	@Override
	public void setValue(VertexInterface vertex, VertexInterface value) {
		this.correspondance.put(vertex, value);
	}

	@Override
	public VertexInterface getValue(VertexInterface vertex) {
		return this.correspondance.get(vertex);
	}

	@Override
	public ArrayList<VertexInterface> getShortestPathTo(VertexInterface vertex) {
		VertexInterface pere = vertex;
		ArrayList<VertexInterface> chemin = new ArrayList<VertexInterface>();
		
		while(this.correspondance.containsKey(pere)){
			chemin.add(0, pere);
			pere = this.correspondance.get(pere);
		}
		chemin.add(0, pere);
		return chemin;
	}
}

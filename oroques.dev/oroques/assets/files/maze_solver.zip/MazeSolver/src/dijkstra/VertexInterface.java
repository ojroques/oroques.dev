package dijkstra;

/** Interface of the vertices occurring in the Dijkstra algorithm. */

public interface VertexInterface {
	
	/** Return the label of the vertex.
	 * @return A String. */
	public String getLabel();
}

package dijkstra;
import java.util.ArrayList;

/** Interface of the previous function occurring in the Dijkstra algorithm. */

public interface PreviousInterface {
	
	/** Setting the result for a vertex.
	 * @param vertex The vertex of which the value will be associated to.
	 * @param value The value is also a VertexInterface, which represents the temporary father of the chosen vertex.
	 * @see VertexInterface */
	public void setValue(VertexInterface vertex, VertexInterface value);
	
	/** Returns the value for a vertex or null if this value has not been set. 
	 * @param vertex The vertex to get the value of.
	 * @return A VertexInterface which represents the current father of the chosen vertex.
	 * @see VertexInterface */
	public VertexInterface getValue(VertexInterface vertex);
	
	/** Returns the shortest path from the root to a vertex. 
	 *  @param vertex The vertex of which the shortest path from the root of the graph will be calculated.
	 *  @return An ArrayList of VertexInterface, which is the shortest path from the root to the chosen vertex.
	 *  @see VertexInterface
	 *  @see ArrayList*/
	public ArrayList<VertexInterface> getShortestPathTo(VertexInterface vertex);
}

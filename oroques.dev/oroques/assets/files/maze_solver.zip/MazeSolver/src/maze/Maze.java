package maze;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import dijkstra.*;

/** The implementation of a Maze as a graph.
 *	@see GraphInterface
 */

public class Maze implements GraphInterface {
	
	private MBox[][] maze;
	private int width;
	private int height;

	/**The basic constructor of an empty maze with given width and height.
	 * 
	 * @param w The width of the maze.
	 * @param h The height of the maze.
	 * @see MBox
	 * @see EBox
	 */
	public Maze(int w, int h){
		this.width = w;
		this.height = h;
		maze = new MBox[height][width];
		for(int j = 0; j < width; j++){
			for(int i = 0; i < height; i++){
				maze[i][j] = new EBox(j, i, this);
			}
		}
	}
	
	/**Return the block at a specified location.
	 * 
	 * @param i The y-axis of the box.
	 * @param j The x-axis of the box.
	 * @return A MBox.
	 * @see MBox
	 */
	public MBox getBox(int i, int j) {
		return maze[i][j];
	}
	
	@Override
	public ArrayList<VertexInterface> getAllVertices() {
		ArrayList<VertexInterface> vertices = new ArrayList<VertexInterface>();
		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				if (maze[i][j].getLabel() != "W") {
					vertices.add(maze[i][j]);
				}
			}
		}
		return vertices;
	}
	
	@Override
	public ArrayList<VertexInterface> getSuccessors(VertexInterface vertex) {
		MBox box = (MBox) vertex;
		int posW = box.getCoordinateW();
		int posH = box.getCoordinateH();
		ArrayList<VertexInterface> successors = new ArrayList<VertexInterface>();
		if (posH != 0 && !maze[posH - 1][posW].getLabel().equals("W")) {
			successors.add(maze[posH - 1][posW]);
		}
		if (posH != height - 1 && !maze[posH + 1][posW].getLabel().equals("W")) {
			successors.add(maze[posH + 1][posW]);
		}
		if (posW != 0 && !maze[posH][posW - 1].getLabel().equals("W")) {
			successors.add(maze[posH][posW - 1]);
		}
		if (posW != width - 1 && !maze[posH][posW + 1].getLabel().equals("W")) {
			successors.add(maze[posH][posW + 1]);
		}
		return successors;
	}
	
	@Override
	public int getWeight(VertexInterface src, VertexInterface dst) {
		return 1;
	}

	/** Initialize a new maze from a text file.
	 * 
	 * @param fileName The name of the text file.
	 * @throws MazeReadingException If the format of the file is not valid.
	 */
	public final void initFromTextFile(String fileName)
			throws MazeReadingException {

		FileReader toRead;
		try {
			toRead = new FileReader(fileName);
			BufferedReader file = new BufferedReader(toRead);
			try {
				/* The first two lines of the text file 
				 * gives the height then the width of the maze.*/
				String line = file.readLine();
				int nLine = 0;
				this.height = Integer.parseInt(line);
				line = file.readLine();
				this.width = Integer.parseInt(line);
				this.maze = new MBox[height][width];  // Creates the maze
				line = file.readLine();
				while (line != null) {
					if (line.length() != width) {
						throw new MazeReadingException(fileName, nLine + 1,
								"Les lignes ne sont pas de même longueur.");
					}
					if (nLine + 1 > height) {
						throw new MazeReadingException(fileName, nLine,
								"Le nombre de ligne n'est pas celui attendu.");
					}
					for (int i = 0; i < width; i++) {
						String type = Character.toString(line.charAt(i));
						if (!type.equals("A") && !type.equals("E")
								&& !type.equals("W") && !type.equals("D")) {
							throw new MazeReadingException(fileName, nLine + 1,
									"Un des caractères ne correspond pas à un type de boîte connu.");
						}
						if (type.equals("A")) {
							maze[nLine][i] = new ABox(i, nLine, this);
						}
						if (type.equals("E")) {
							maze[nLine][i] = new EBox(i, nLine, this);
						}
						if (type.equals("W")) {
							maze[nLine][i] = new WBox(i, nLine, this);
						}
						if (type.equals("D")) {
							maze[nLine][i] = new DBox(i, nLine, this);
						}
					}
					nLine += 1;
					line = file.readLine();
				}
			} catch (IOException e) {
				System.out.println("IO error");
			} finally {
				file.close();
			}
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println("IO error");
		}

	}

	/** Save a maze into a text file.
	 * 
	 * @param fileName The name to give to the text file.
	 */
	public final void saveToTextFile(String fileName) {
		try {
			PrintWriter newFile = new PrintWriter(fileName);
			newFile.println(height);
			newFile.println(width);
			for (MBox[] i : maze) {
				for (MBox j : i) {
					newFile.print(j.getLabel());
				}
				newFile.println();
			}
			newFile.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}

package maze;

import dijkstra.VertexInterface;

/** Class for an departure block. It inherits from MBox and gets the label 'B'.
 * @see MBox
 * @see VertexInterface
 */

public class DBox extends MBox {
	
	/**Constructor
	 * 
	 * @param coordinateW The x-axis coordinate (in blocks).
	 * @param coordinateH The y-axis coordinate (in blocks).
	 * @param masterMaze  The main maze.
	 */
	public DBox (int coordinateW, int coordinateH, Maze masterMaze)
	{
		super(coordinateW, coordinateH, masterMaze, "D") ;
	}
	
}

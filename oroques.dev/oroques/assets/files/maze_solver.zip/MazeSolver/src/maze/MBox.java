package maze;

import dijkstra.*;

/** The implementation of a maze block. A maze block is also a vertex in the associated graph, 
 * hence the inheritance from VertexInterface.
 */

public abstract class MBox implements VertexInterface {
	
	private final int coordinateW ;
	private final int coordinateH ;
	private final Maze masterMaze ; 
	private String label ; 
	
	/**Constructor of a regular block.
	 * 
	 * @param coordinateW The x-axis coordinate (in blocks).
	 * @param coordinateH The y-axis coordinate (in blocks).
	 * @param masterMaze  The main maze.
	 * @param label The label of the box.
	 */
	public MBox(int coordinateW, int coordinateH, Maze masterMaze, String label) {
		this.coordinateW = coordinateW;
		this.coordinateH = coordinateH;
		this.masterMaze = masterMaze ;
		this.label = label ;
	}
	
	/** Return the x-axis coordinate. 
	 * @return The x-axis coordinate in blocks, as an integer.
	 */
	public final int getCoordinateW() {
		return this.coordinateW;
	}
	
	/** Return the y-axis coordinate. 
	 * @return The y-axis coordinate in blocks, as an integer.
	 */
	public final int getCoordinateH() {
		return this.coordinateH;
	}
	
	/** Return the main maze. 
	 * @return A Maze object.
	 * @see Maze
	 */
	public final Maze getMasterMaze(){
		return this.masterMaze;
	}
	
	/** Set the label of a box. 
	 * @param t The label to attach to this box object.
	 */
	public void setLabel(String t){
		this.label = t;
	}
	
	@Override
	public String getLabel(){
		return this.label ;
	}
	
}

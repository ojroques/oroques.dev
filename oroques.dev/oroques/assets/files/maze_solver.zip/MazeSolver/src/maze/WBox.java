package maze;

import dijkstra.VertexInterface;

/** Class for an wall block. It inherits from MBox and gets the label 'W'.
 * @see MBox
 * @see VertexInterface
 */

public class WBox extends MBox {
	
	/**Constructor
	 * 
	 * @param coordinateW The x-axis coordinate (in blocks).
	 * @param coordinateH The y-axis coordinate (in blocks).
	 * @param masterMaze  The main maze.
	 */
	public WBox (int coordinateW, int coordinateH, Maze masterMaze)
	{
		super(coordinateW, coordinateH, masterMaze, "W") ;
	}

}

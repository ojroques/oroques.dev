package maze;

import dijkstra.VertexInterface;

/** Class for an empty block. It inherits from MBox and gets the label 'E'.
 * @see MBox
 * @see VertexInterface
 */

public class EBox extends MBox {
	
	/**Constructor
	 * 
	 * @param coordinateW The x-axis coordinate (in blocks).
	 * @param coordinateH The y-axis coordinate (in blocks).
	 * @param masterMaze  The main maze.
	 */
	public EBox (int coordinateW, int coordinateH, Maze masterMaze)
	{
		super(coordinateW, coordinateH, masterMaze, "E") ;
	}

}

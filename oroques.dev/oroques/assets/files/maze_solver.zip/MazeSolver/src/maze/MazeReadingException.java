package maze;

/** An exception class to detect whether or not the format of a text file matches
 * the one used in Maze.
 * @see Maze#saveToTextFile(String)
 * @see Maze#initFromTextFile(String)
 */

@SuppressWarnings("serial")
public class MazeReadingException extends Exception{
	
	private final String NAME;
	
	/** Constructor: prints and locates the error detected.
	 * 
	 * @param name The name of the corrupted file.
	 * @param line The line where the error has been detected.
	 * @param message The message to be print.
	 */
	public MazeReadingException(String name, int line, String message){
		super("Erreur à la ligne " + line + " du fichier " + name + ": " + message);
		this.NAME = name;
	}
	
	/**Return the error message.
	 * @return A String
	 */
	public String getName(){
		return NAME;
	}
}
package interfaces;

import java.awt.event.*;
import javax.swing.* ;
import main.MainMaze;

/** The Edit menu inside the menu bar. */

public final class EditMenu extends JMenu implements ActionListener
{
	private static final long serialVersionUID = 3023580299373211491L;
	private final MainMaze maze;
	private JMenuItem clear, resolve;
	
	/** Constructor:
	 * @param maze The current maze.
	 */
	public EditMenu(MainMaze maze)
	{
		super("Edit");
		this.maze = maze;
		this.clear = new JMenuItem("Clear");
		this.resolve = new JMenuItem("Resolve the maze");
		
		clear.addActionListener(this);
		resolve.addActionListener(this);

		add(clear);
		clear.setAccelerator(KeyStroke.getKeyStroke((char) KeyEvent.VK_E));
		add(resolve);
		resolve.setAccelerator(KeyStroke.getKeyStroke((char) KeyEvent.VK_R));
	}
	
	@Override
	public void actionPerformed(ActionEvent ev){
		if (ev.getSource() == clear){
			maze.reinit();
		}
		if (ev.getSource() == resolve){
			maze.resolve();
		}
	}
}
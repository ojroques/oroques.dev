package interfaces;

import javax.swing.* ;
import main.MainMaze;

/** The Menu Bar of the game frame. */

public final class GameMenuBar extends JMenuBar
{
	static final long serialVersionUID = 201503101423L ;
	
	public GameMenuBar(GameFrame gameWindow, MainMaze maze)
	{
		super() ;	
		add(new FileMenu(gameWindow, maze)) ;
		add(new EditMenu(maze));
	}

}

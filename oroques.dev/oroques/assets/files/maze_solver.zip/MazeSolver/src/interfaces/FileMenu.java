package interfaces;

import java.awt.event.*;
import javax.swing.* ;
import main.MainMaze;

/** The File menu inside the menu bar. */

public final class FileMenu extends JMenu implements ActionListener
{
	static final long serialVersionUID = 201503101423L ;
	private final MainMaze maze;
	private JFrame frame;
	private JMenuItem open, save, instructions, about;
	
	/** Constructor:
	 * @param gameFrame The current Java frame.
	 * @param maze The current maze.
	 */
	public FileMenu(GameFrame gameFrame, MainMaze maze)
	{
		super("File");
		this.maze = maze;
		this.frame = gameFrame;
		this.open = new JMenuItem("Open");
		this.save = new JMenuItem("Save as");
		this.instructions = new JMenuItem("Instructions");
		this.about = new JMenuItem("About");
		
		open.addActionListener(this);
		save.addActionListener(this);
		instructions.addActionListener(this);
		about.addActionListener(this);
		
		add(open);
		open.setAccelerator(KeyStroke.getKeyStroke((char) KeyEvent.VK_O));
		add(save);
		save.setAccelerator(KeyStroke.getKeyStroke((char) KeyEvent.VK_S));
		add(instructions);
		add(about);
		add(new QuitMenuItem(gameFrame)) ;
	}
	
	@Override
	public void actionPerformed(ActionEvent ev){
		Object source = ev.getSource();
		if (source == open){
			maze.open();
		}
		if (source == save){
			maze.saveAs();
		}
		if (source == instructions){
			maze.printInformations();
		}
		if (source == about){
			JOptionPane.showMessageDialog(frame, "Auteurs: Erwan CULERIER & Olivier ROQUES\n"
				+ "Pour le projet Java 2016-2017 de Télécom ParisTech \n"
				+ "erwan.culerier@telecom-paristech.fr\n"
				+ "olivier.roques@telecom-paristech.fr", "Crédits", JOptionPane.INFORMATION_MESSAGE);
		}
	}
}

from tkinter import *
from ScrolledCanvas import *
from Motifs import *
import pickle
#Module donnant acces aux fenetres pour la recherche de fichiers:
from tkinter.filedialog import asksaveasfile, askopenfile


class JeuDeLaVie(Frame):
    """La classe principale du jeu de la vie, avec toutes ses fonctions."""
    def __init__(self, master, **args):
        Frame.__init__(self, master, **args)

        self.width       = 1800         #Largeur du canevas
        self.height      = 1680         #Hauteur du canevas
        self.vitesse     = 50           #Vitesse par defaut de la simulation
        self.coul_fond   = "#303030"    #Couleur du fond par defaut
        self.coul_cel    = "#FFFFFF"    #Couleur des cases vivantes par defaut
        self.coul_lignes = "#707070"    #Couleur des lignes de separation par defaut
        self.flag = 0                   #Variable de controle: simulation active ou non
        
        self.img = [PhotoImage(file="icones/play.gif"),                #Liste contenant les icones des boutons de controle
                    PhotoImage(file="icones/pause.gif"),
                    PhotoImage(file="icones/stop.gif"),
                    PhotoImage(file="icones/restart.gif")]
        
        self.palette_coul = [PhotoImage(file="icones/palette1.gif"),   #Liste contenant les icones des boutons de choix de couleur
                             PhotoImage(file="icones/palette2.gif"),
                             PhotoImage(file="icones/palette3.gif"),
                             PhotoImage(file="icones/palette4.gif"),
                             PhotoImage(file="icones/palette5.gif"),
                             PhotoImage(file="icones/palette6.gif")]
        
        self.img_motif = [PhotoImage(file="icones/ants.gif"),          #Liste contenant les icones des boutons de motifs
                          PhotoImage(file="icones/LWSS.gif"),
                          PhotoImage(file="icones/galaxy.gif"),
                          PhotoImage(file="icones/GosperGliderGun.gif"),
                          PhotoImage(file="icones/Acorn.gif"),
                          PhotoImage(file="icones/Light_Bulb.gif")]

        #Espace de simulation, avec barres de defilement
        board = ScrolledCanvas(self, height=600, width=800, bg=self.coul_fond,
                                  scrollregion =(0, 0, self.width, self.height))
        board.grid(row=0, column=0)
        self.can = board.canvas
        
        #Cadre de gestion (boutons de controle + informations)
        cadre_info = Frame(self, bd=2, relief=GROOVE)
        cadre_info.grid(row=1, column=0, pady=3, padx=3, sticky=EW)

        #Cadre d'options
        cadre_motif = Frame(self, bd=2, relief=GROOVE)
        cadre_motif.grid(row=0, column=1, pady=3, padx=3, sticky=NS)
        Button(cadre_motif, text="Le Jeu de la Vie", command=self.affiche_regle, font="Arial 13 bold", bd=2, relief=SOLID)\
                           .grid(row=0, column=0, columnspan=6, padx=3, pady=5, sticky=EW)
               
        #Boutons de controle (cadre de gestion)
        Button(cadre_info, image=self.img[3], command=self.reinit_motif)\
                              .pack(side=RIGHT, padx=2, pady=2) #Restart
        Button(cadre_info, image=self.img[2], command=self.new_board)\
                              .pack(side=RIGHT, padx=2, pady=2) #Nouvelle simulation
        self.bout_play = Button(cadre_info)
        self.bout_play.pack(side=RIGHT, padx=2, pady=2)         #Start

        #Cadre d'information
        self.showgen = Label(cadre_info, text="Generation: 0", font="Arial 11 bold")
        self.showgen.pack(side=LEFT, padx=5, pady=2)
        self.showpop = Label(cadre_info, text="Cellule vivante: 0", font="Arial 11 bold")
        self.showpop.pack(side=LEFT, padx=120, pady=2)

        #Curseur de choix de la vitesse (cadre d'options)
        curseur = Scale(cadre_motif, orient=HORIZONTAL, troughcolor="dark grey", label="Vitesse (en ms):", from_=20, to=2000, command=self.change_vitesse, tickinterval=660)
        curseur.grid(row=1, column=0, columnspan=6, padx=3, sticky=EW)
        curseur.set(50)
        
        #Boutons de choix de couleur (cadre d'options)
        Label(cadre_motif, text="Choix des couleurs:")\
                           .grid(row=2, column=0, columnspan=6, padx=3, pady=5, sticky=W)
                #On utilise 'lambda' pour transmettre un parametre a la fonction appelee, ici les couleurs
        Button(cadre_motif, image=self.palette_coul[0], command=lambda c1="#303030", c2="#FFFFFF", c3="#707070": self.change_coul(c1, c2, c3), bd=1, relief=SOLID)\
                           .grid(row=3, column=0, columnspan=3, padx=3, pady=2, sticky=W)
        Button(cadre_motif, image=self.palette_coul[1], command=lambda c1="#AA82B4", c2="#FAF0F0", c3="#6E646E": self.change_coul(c1, c2, c3), bd=1, relief=SOLID)\
                           .grid(row=3, column=3, columnspan=3, padx=3, pady=2, sticky=W)
        Button(cadre_motif, image=self.palette_coul[2], command=lambda c1="#96AAF0", c2="#F0960A", c3="#828296": self.change_coul(c1, c2, c3), bd=1, relief=SOLID)\
                           .grid(row=4, column=0, columnspan=3, padx=3, pady=2, sticky=W)
        Button(cadre_motif, image=self.palette_coul[3], command=lambda c1="#B4E6B4", c2="#826E5A", c3="#82A08C": self.change_coul(c1, c2, c3), bd=1, relief=SOLID)\
                           .grid(row=4, column=3, columnspan=3, padx=3, pady=2, sticky=W)
        Button(cadre_motif, image=self.palette_coul[4], command=lambda c1="#3C503C", c2="#F0DCBE", c3="#142814": self.change_coul(c1, c2, c3), bd=1, relief=SOLID)\
                           .grid(row=5, column=0, columnspan=3, padx=3, pady=2, sticky=W)
        Button(cadre_motif, image=self.palette_coul[5], command=lambda c1="#323C5A", c2="#B4B4C8", c3="#32323C": self.change_coul(c1, c2, c3), bd=1, relief=SOLID)\
                           .grid(row=5, column=3, columnspan=3, padx=3, pady=2, sticky=W)

        #Boutons de choix d'un motif particulier (cadre d'options)
        Label(cadre_motif, text="Motifs particuliers:")\
                           .grid(row=6, column=0, columnspan=6, padx=3, pady=5, sticky=W)
        Button(cadre_motif, image=self.img_motif[0], command=self.draw_ants)\
                            .grid(row=7, column=0, columnspan=2, pady=2, sticky=E)
        Button(cadre_motif, image=self.img_motif[1], command=self.draw_LWSS)\
                            .grid(row=7, column=2, columnspan=2, pady=2)
        Button(cadre_motif, image=self.img_motif[2], command=self.draw_galaxy)\
                            .grid(row=7, column=4, columnspan=2, pady=2, sticky=W)
        Button(cadre_motif, image=self.img_motif[3], command=self.draw_GosperGliderGun)\
                            .grid(row=8, column=0, columnspan=2, pady=2, sticky=E)
        Button(cadre_motif, image=self.img_motif[4], command=self.draw_Acorn)\
                            .grid(row=8, column=2, columnspan=2, pady=2)
        Button(cadre_motif, image=self.img_motif[5], command=self.draw_Light_Bulb)\
                            .grid(row=8, column=4, columnspan=2, pady=2, sticky=W)

        #Bouton d'import/export de motifs (cadre d'options)
        Label(cadre_motif, text="Import/Export de motif:")\
                           .grid(row=9, column=0, columnspan=6, padx=3, pady=5, sticky=W)
        Button(cadre_motif, text="Ouvrir", command=self.import_motif)\
                            .grid(row=10, column=0, columnspan=3, padx=3, sticky=EW)
        Button(cadre_motif, text="Enregistrer", command=self.save_motif)\
                            .grid(row=10, column=3, columnspan=3, padx=3, sticky=EW)

        #Selon les boutons de la souris appuyes, effectue une action
        self.can.bind("<Button-1>", self.set_life)
        self.can.bind("<Button-3>", self.set_death)
        self.can.bind("<B1-Motion>", self.set_life)
        self.can.bind("<B3-Motion>", self.set_death)

        #Bouton d'arret du programme
        Button(self, text="Quitter", command=self.master.destroy)\
                     .grid(row=1, column=1, padx=6, pady=2, sticky=E)
        
        self.new_board() #Demarre une nouvelle partie
        
    def new_board(self):
        "Dessine l'espace de simulation et initialise les variables."
        if self.flag:   #Si simulation en cours, la stoppe
            self.flag = 0
            self.after(self.vitesse, self.new_board)  #Permet d'eviter une animation en trop en attendant la fin de la simulation
            return
        
        self.can.delete(ALL)      #Efface le canevas
        
        #Initialisations de variables
        self.dico_case = {}     #Dictionnaire des coordonees des cellules vivantes
        self.dico_copie = None  #Copie du dictionnaire, pour recommencer une simulation avec un meme motif

        self.draw_lines()       #Dessine les lignes
        self.change_bouton(1)   #Affichage du bouton Play
        
        self.generation = 0                             #Variable compteur de generation
        self.showgen.config(text="Generation: 0")       #On reinitialise les deux compteurs
        self.showpop.config(text="Cellule vivante: 0")
        
    def draw_lines(self):
        "Dessine les lignes du canevas."
        for i in range(0, self.width+12, 12):     #Lignes horizontales
            self.can.create_line(i, 0, i, self.height, width=1, fill=self.coul_lignes)
            
        for j in range(0, self.height+12, 12):    #Lignes verticales
            self.can.create_line(0, j, self.width, j, width=1, fill=self.coul_lignes)

    def set_life(self, event):
        "Donne vie à une cellule."
        canvas_coord = event.widget
        x = canvas_coord.canvasx(event.x + 3 - (event.x%12)) #Coordonnes x du clic
        y = canvas_coord.canvasy(event.y + 3 - (event.y%12)) #Coordonnes x du clic        
        
        if 0 <= x <= self.width and 0 <= y <= self.height:
            #Change la couleur de la case si le clic est dans l'espace de simulation
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1    #La cellule est maintenant vivante (1)
            self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))  #On actualise le compteur de cellule
            
    def set_death(self, event):
        "Efface une cellule vivante."
        if self.flag: return
        canvas_coord = event.widget
        x = canvas_coord.canvasx(event.x + 3 - (event.x%12))
        y = canvas_coord.canvasy(event.y + 3 - (event.y%12))
        
        if (x, y) in self.dico_case.keys():
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_fond, outline=self.coul_lignes)
            del self.dico_case[x, y]    #La cellule est maintenant morte (0)
            self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))

    def change_bouton(self, etat):
        "Modifie le bouton 'Play'."
        if etat: self.bout_play.config(image=self.img[0], command=self.start)     #Bouton Play
        else:    self.bout_play.config(image=self.img[1], command=self.pause)     #Bouton Pause

    def change_vitesse(self, v):
        "Change la vitesse avec celle choisie par l'utilisateur."
        self.vitesse = v

    def start(self, event=None):
        "Demarrage de l'animation."
        if not self.flag:                             #Evite de lancer la simulation lorsqu'une autre est en cours
            self.dico_copie = self.dico_case.copy()   #Effectue une copie du dictionnaire
            self.flag = 1                             #Autorise la simulation
            self.animation()                          #Appel de la fonction animant la simulation
            self.change_bouton(0)                     #Change l'etat du bouton play

    def pause(self, event=None):
        "Mise en pause de l'animation."
        self.flag = 0               #Stoppe la simulation
        self.change_bouton(1)

    def reinit_motif(self, event=None):
        "Redemarre une simulation avec le meme motif."
        if self.dico_copie:     #Ne s'execute que dans le cas ou une copie du motif initial existe
            if self.flag:
                self.pause()
                self.after(self.vitesse, self.reinit_motif)  #Permet d'eviter une animation en trop en attendant la fin de la simulation
                return

            self.dico_case = self.dico_copie.copy()          #Le dico principal prend les meme valeur que la copie

            self.generation = 0                             #On reinitialise la generation et 
            self.showgen.config(text="Generation: 0")       #on actualise le compteur de cellule
            self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))

            self.can.delete(ALL)
            self.draw_lines()
            
            self.redessine_canvas()     #Redessine l'ancien motif                

    def animation(self):
        dico_etat = {}     #Contient pour chaque case le nombre de cellules vivantes adjacentes qu'il possede

        for (x, y) in self.dico_case.keys():
            dico_etat[x, y] = 0

        #Boucle qui compte le nombre de cellules vivantes autour de chaque cases et stocke le nombre
        #dans dico_etat, aux coordonnees correspondantes. Si la case est deja dans le dictionnaire, on
        #lui ajoute +1, sinon on la cree
        for (x, y) in self.dico_case.keys():
            try:    dico_etat[x-12, y-12] += 1
            except: dico_etat[x-12, y-12]  = 1
            try:    dico_etat[x-12, y]    += 1
            except: dico_etat[x-12, y]     = 1
            try:    dico_etat[x-12, y+12] += 1
            except: dico_etat[x-12, y+12]  = 1
            try:    dico_etat[x, y-12]    += 1
            except: dico_etat[x, y-12]     = 1
            try:    dico_etat[x, y+12]    += 1
            except: dico_etat[x, y+12]     = 1
            try:    dico_etat[x+12, y-12] += 1
            except: dico_etat[x+12, y-12]  = 1
            try:    dico_etat[x+12, y]    += 1
            except: dico_etat[x+12, y]     = 1
            try:    dico_etat[x+12, y+12] += 1
            except: dico_etat[x+12, y+12]  = 1

        self.can.delete(ALL)
        self.draw_lines()
        
        #Cette boucle redessine le nouveau canevas, selon les regles du Jeu de la Vie
        for (x, y) in dico_etat.keys():
            if dico_etat[x, y] == 3:   #Si 3 cellules vivantes adjacentes, la case prend vie
                self.dico_case[x, y] = 1
                self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            elif (dico_etat[x, y] == 2) and ((x, y) in self.dico_case.keys()): #Si exactement 2, la case reste dans le meme etat
                self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            elif (x, y) in self.dico_case.keys(): #Dans les autres cas, elle meurt
                del self.dico_case[x, y] #On efface alors les coordonnes de l'ancienne cellule vivante du dictionnaire

        self.generation += 1    #La generation est incremente de 1, puis on actualise les deux compteurs
        self.showgen.config(text="Generation: "+str(self.generation))
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))

        if self.flag:        #Recommence l'animation du debut, apres un certain temps 'vitesse' (en ms)
            self.after(self.vitesse, self.animation)

    def change_coul(self, coul_fond, coul_cel, coul_lignes):
        "Change la couleur du fond, des cellules et des lignes de separation."
        self.can.config(bg=coul_fond)  #Change la couleur du fond
        self.coul_fond   = coul_fond   #Sauvegarde la couleur du fond en cas d'un clic droit
        self.coul_cel    = coul_cel    #Change couleur des cellules
        self.coul_lignes = coul_lignes #Change couleur des lignes
        self.draw_lines()              #Applique le changement de couleur aux lignes
        self.redessine_canvas()        #Redessine les cellules avec la nouvelle couleur  

    def draw_ants(self):
        "Dessine le motif 'ants'."
        motif = ants()      #On recupere les coordonnees du motif contenue dans le fichier 'Motifs.py' dans un tableau
        #Pour chaque coordonnee du tableau, on dessine sa cellule et on stocke sa valeur dans le dictionnaire
        for (x, y) in motif:
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))  #On actualise enfin le compteur de cellule

    def draw_LWSS(self):
        "Dessine le motif 'LWSS'."
        motif = LWSS()
        for (x, y) in motif:
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))

    def draw_galaxy(self):
        "Dessine le motif 'galaxy'."
        motif = galaxy()
        for (x, y) in motif:
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))

    def draw_GosperGliderGun(self):
        "Dessine le motif 'GosperGliderGun'."
        motif = GosperGliderGun()
        for (x, y) in motif:
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))
            
    def draw_Acorn(self):
        "Dessine le motif 'Acorn'."
        motif = Acorn()
        for (x, y) in motif:
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))
    
    def draw_Light_Bulb(self):
        "Dessine le motif 'Light_Bulb'."
        motif = Light_Bulb()
        for (x, y) in motif:
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)
            self.dico_case[x, y] = 1
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))
         
    def import_motif(self):
        "Ouvre un motif a partir d'un fichier .motf."
        if self.flag:   #On met en pause la simulation si elle est active
            self.pause()
            self.after(self.vitesse, self.import_motif)
            return
        
        #Ouvre la fenetre d'importation
        fichier = askopenfile(mode="rb", filetypes=[("Motif",".motf")], defaultextension=".motf")
        if not fichier: return      #Si l'utilisateur ferme la fenetre, quitte la fonction
        
        try:        #On tente de recuperer le dictionnaire a l'aide du module Pickle
            motif = pickle.Unpickler(fichier)
            dico = motif.load()
            fichier.close()
        except:     #Si une erreur survient, on ferme le fichier et on quitte la fonction
            fichier.close()
            return

        self.new_board()        #On efface le canevas
        self.dico_case = dico   #Le dictionnaire est actualise avec celui imorte
        self.showpop.config(text="Cellule vivante: "+str(len(self.dico_case)))   #Le compteur de cellule vivante est mis a jour
        self.redessine_canvas() #Redessine le nouveau motif        

    def save_motif(self):
        "Sauvegarde un motif dans un fichier .motf."
        if self.flag:
            self.pause()
            self.after(self.vitesse, self.save_motif)
            return

        #Ouvre la fenetre de sauvegarde    
        fichier = asksaveasfile(mode="wb", filetypes=[("Motif",".motf")], defaultextension=".motf")
        if not fichier: return          
        dico = pickle.Pickler(fichier)  #On utilise le module Pickle pour sauvegarder le dictionnaire
        dico.dump(self.dico_case)       
        fichier.close()                 #Fermeture du fichier
        
    def redessine_canvas(self):
        "Redessine le canevas selon le dictionnaire principal."
        for x, y in self.dico_case.keys():
            self.can.create_rectangle(x, y, x+12, y+12, fill=self.coul_cel, outline=self.coul_lignes)

    def affiche_regle(self):
        "Affiche des informations sur le jeu de la vie dans une fenetre a part."
        fen_regle = Toplevel(self) #Creation de la fenetre
        fen_regle.title("Informations et regles du Jeu de la Vie")
        can_texte = Canvas(fen_regle, width = 400, height = 380, bg="#F0F0F0") #Canevas contenant l'image du texte
        can_texte.pack()
        self.txt = PhotoImage(file="icones/infos.gif")      #Variable qui contient l'image du texte
        can_texte.create_image(200, 190, image=self.txt)    #On place alors l'image au centre du canevas
        
        
if __name__ == "__main__":
    fen = Tk()
    fen.title("Jeu de la vie")
    fen.resizable(width=False, height=False)
    JeuDeLaVie(fen).pack()
    fen.mainloop()

from tkinter import *

class ScrolledCanvas(Frame):
    """Canevas extensible avec barres de defilement"""
    def __init__(self, boss, width, height, bg, scrollregion):
        
        Frame.__init__(self, boss)
        
        #Espace principal de la simulation
        self.canvas = Canvas(self, width=width-20, height=height-20, bg=bg,
                         scrollregion=scrollregion, bd=1, relief=RIDGE)
        self.canvas.grid(row=0, column=0)

        #Initialise les barres de defilement
        bdv = Scrollbar(self, orient=VERTICAL, command=self.canvas.yview, bd=1)
        bdh = Scrollbar(self, orient=HORIZONTAL, command=self.canvas.xview, bd=1)
        
        self.canvas.configure(xscrollcommand=bdh.set, yscrollcommand=bdv.set, \
                              yscrollincrement="12", xscrollincrement="12")

        #Positions des barres
        bdv.grid(row=0, column=1, sticky=NS)      
        bdh.grid(row=1, column=0, sticky=EW)
        
        self.bind("<Configure>", self.redim)
        self.started=False

    def redim(self, event):
        "Operations a effectuer a chaque redimensionnement du widget."
        
        if not self.started:
            self.started =True     
            return

        #Permet de se deplacer dans le canvas
        larg, haut = self.winfo_width()-20, self.winfo_height()-20
        self.canvas.config(width=larg, height=haut)
